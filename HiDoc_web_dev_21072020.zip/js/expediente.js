$(function () {
    $('.record-perk.hoja-frontal').hover(function () {
        $('.visualiza-image').attr('src', 'images/expediente/visualiza/hoja-frontal.png');
    });
    $('.record-perk.historial-clinico').hover(function () {
        $('.visualiza-image').attr('src', 'images/expediente/visualiza/historial-clinico.png');
    });
    $('.record-perk.estudios-y-anexos').hover(function () {
        $('.visualiza-image').attr('src', 'images/expediente/visualiza/estudios-y-anexos.png');
    });
    $('.record-perk.cartilla-vacunacion').hover(function () {
        $('.visualiza-image').attr('src', 'images/expediente/visualiza/cartilla-vacunacion.png');
    });
});